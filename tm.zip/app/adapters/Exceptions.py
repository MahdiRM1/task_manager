class IdNotFound(Exception):
    pass

class NameNotFound(Exception):
    pass