from enum import Enum, auto

class TaskStatus(Enum):
    TODO = auto()
    DONE = auto()